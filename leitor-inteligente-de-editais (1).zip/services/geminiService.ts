import { GoogleGenAI, Type, Chat, GenerateContentResponse } from '@google/genai';
import type { EditalSummary } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const summarySchema = {
    type: Type.OBJECT,
    properties: {
        orgao_licitante: {
            type: Type.OBJECT,
            properties: {
                nome: { type: Type.STRING, description: 'Nome completo do órgão licitante.' },
                cnpj: { type: Type.STRING, description: 'CNPJ do órgão.' },
                endereco: { type: Type.STRING, description: 'Endereço completo do órgão.' },
                telefone: { type: Type.STRING, description: 'Telefone de contato.' },
                email: { type: Type.STRING, description: 'E-mail de contato.' },
                responsavel: { type: Type.STRING, description: 'Nome do responsável pela licitação (pregoeiro, comissão, etc.).' }
            },
            required: ['nome']
        },
        objeto_licitacao: { type: Type.STRING, description: 'Descrição clara e completa do objeto da licitação.' },
        tipo_disputa: { type: Type.STRING, description: 'Modalidade da licitação (ex: Pregão Eletrônico, Concorrência, Tomada de Preços).' },
        portal_processo: {
            type: Type.OBJECT,
            properties: {
                portal: { type: Type.STRING, description: 'Portal onde a licitação ocorre (ex: Comprasnet, Licitações-e).' },
                numero_processo: { type: Type.STRING, description: 'Número do processo ou do edital.' }
            }
        },
        datas_principais: {
            type: Type.OBJECT,
            properties: {
                abertura: { type: Type.STRING, description: 'Data e hora da abertura da sessão.' },
                disputa: { type: Type.STRING, description: 'Data e hora do início da disputa de lances.' },
                entrega_propostas: { type: Type.STRING, description: 'Data e hora limite para entrega das propostas.' },
                pagamento: { type: Type.STRING, description: 'Condições ou prazo para o pagamento.' },
                validade_proposta: { type: Type.STRING, description: 'Prazo de validade da proposta comercial.' }
            }
        },
        requisitos_habilitacao: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: 'Lista dos principais documentos e requisitos para habilitação.'
        },
        criterio_julgamento: { type: Type.STRING, description: 'Critério para julgamento das propostas (ex: Menor Preço, Técnica e Preço).' },
        principais_itens: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    item: { type: Type.STRING, description: 'Número do item.' },
                    descricao: { type: Type.STRING, description: 'Descrição resumida do item.' },
                    quantidade: { type: Type.NUMBER, description: 'Quantidade do item.' },
                    unidade: { type: Type.STRING, description: 'Unidade de medida do item (ex: UN, KG, CX).' }
                },
                required: ['descricao']
            },
            description: 'Lista dos principais itens/lotes licitados.'
        },
        outros_dados: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: 'Outras informações relevantes como prazos de entrega, garantias, penalidades, local de execução, etc.'
        }
    },
    required: ['orgao_licitante', 'objeto_licitacao', 'tipo_disputa', 'requisitos_habilitacao', 'criterio_julgamento', 'principais_itens']
};

export const generateSummary = async (text: string): Promise<EditalSummary> => {
    const prompt = `Você é um especialista em licitações públicas. Sua tarefa é analisar o texto de um edital e extrair as informações mais importantes de forma estruturada.

    Aqui está o texto do edital:
    ---
    ${text}
    ---

    Por favor, extraia as informações conforme o schema JSON fornecido e retorne um JSON válido. Seja objetivo e preciso.`;

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: summarySchema,
            },
        });
        
        const jsonText = response.text.trim();
        return JSON.parse(jsonText) as EditalSummary;

    } catch (error) {
        console.error("Error generating summary:", error);
        throw new Error("Não foi possível gerar o resumo. A IA pode estar sobrecarregada ou o formato do texto não é compatível.");
    }
};

export const startChatSession = async (context: string): Promise<Chat> => {
    const systemInstruction = `Você é um assistente especializado em analisar editais de licitação. Suas respostas devem ser baseadas EXCLUSIVAMENTE no texto do edital fornecido a seguir. Seja formal, técnico e claro. Use emojis para tornar a comunicação mais amigável. Se a informação solicitada não estiver no texto, responda EXATAMENTE: "Essa informação não foi encontrada no edital enviado. 🧐".
    
    --- CONTEÚDO DO EDITAL ---
    ${context}
    --- FIM DO CONTEÚDO ---
    `;
    
    const chat: Chat = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
            systemInstruction: systemInstruction,
        },
    });
    return chat;
};

export const sendMessageToChat = async (chat: Chat, message: string): Promise<string> => {
    try {
        const response: GenerateContentResponse = await chat.sendMessage({ message });
        return response.text;
    } catch (error) {
        console.error("Error sending message:", error);
        throw new Error("Erro ao se comunicar com a IA.");
    }
};
