export interface EditalSummary {
    orgao_licitante: {
        nome: string;
        cnpj?: string;
        endereco?: string;
        telefone?: string;
        email?: string;
        responsavel?: string;
    };
    objeto_licitacao: string;
    tipo_disputa: string;
    portal_processo: {
        portal?: string;
        numero_processo?: string;
    };
    datas_principais: {
        abertura?: string;
        disputa?: string;
        entrega_propostas?: string;
        pagamento?: string;
        validade_proposta?: string;
    };
    requisitos_habilitacao: string[];
    criterio_julgamento: string;
    principais_itens: {
        item?: string;
        descricao: string;
        quantidade?: number;
        unidade?: string;
    }[];
    outros_dados: string[];
}

export interface ChatMessage {
    sender: 'user' | 'ai';
    message: string;
}
