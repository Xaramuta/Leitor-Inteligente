import React, { useState, useRef } from 'react';
import type { Chat } from '@google/genai';
import { FileUpload } from './components/FileUpload';
import { LoadingAnimation } from './components/LoadingAnimation';
import { SummaryDisplay } from './components/SummaryDisplay';
import { ChatWindow } from './components/ChatWindow';
import { Header } from './components/Header';
import { PrintLayout } from './components/PrintLayout';
import { PrintIcon } from './components/icons';
import { extractTextFromFile } from './utils/fileProcessor';
import { generateSummary, startChatSession, sendMessageToChat } from './services/geminiService';
import type { EditalSummary, ChatMessage } from './types';

function App() {
    const [currentFile, setCurrentFile] = useState<File | null>(null);
    const [summary, setSummary] = useState<EditalSummary | null>(null);
    const [chatSession, setChatSession] = useState<Chat | null>(null);
    const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
    const [error, setError] = useState<string | null>(null);
    const [isLoadingSummary, setIsLoadingSummary] = useState<boolean>(false);
    const [isChatting, setIsChatting] = useState<boolean>(false);
    const printRef = useRef<HTMLDivElement>(null);

    const handleFileSelect = async (file: File) => {
        // Reset state for new file
        setCurrentFile(file);
        setSummary(null);
        setChatSession(null);
        setChatHistory([]);
        setError(null);
        setIsLoadingSummary(true);

        try {
            const text = await extractTextFromFile(file);
            const summaryResult = await generateSummary(text);
            setSummary(summaryResult);
            const chat = await startChatSession(text);
            setChatSession(chat);
        } catch (e: any) {
            setError(e.message || 'Ocorreu um erro desconhecido ao processar o arquivo.');
        } finally {
            setIsLoadingSummary(false);
        }
    };

    const handleSendMessage = async (message: string) => {
        if (!chatSession) {
            setError("A sessão de chat não foi iniciada. Por favor, carregue um edital primeiro.");
            return;
        }

        const newUserMessage: ChatMessage = { sender: 'user', message };
        setChatHistory(prev => [...prev, newUserMessage]);
        setIsChatting(true);
        setError(null);

        try {
            const aiResponse = await sendMessageToChat(chatSession, message);
            const newAiMessage: ChatMessage = { sender: 'ai', message: aiResponse };
            setChatHistory(prev => [...prev, newAiMessage]);
        } catch (e: any) {
            const errorMessage = e instanceof Error ? e.message : 'Desculpe, ocorreu um erro ao se comunicar com a IA.';
            setError(errorMessage);
            const errorChatMessage: ChatMessage = { sender: 'ai', message: errorMessage };
            setChatHistory(prev => [...prev, errorChatMessage]);
        } finally {
            setIsChatting(false);
        }
    };
    
    const handlePrint = () => {
        const printWindow = window.open('', '_blank');
        if (!printWindow || !printRef.current) {
            alert('Não foi possível abrir a janela de impressão. Verifique se o seu navegador está bloqueando pop-ups.');
            return;
        }
        
        const content = printRef.current.innerHTML;
        printWindow.document.write(`
            <html>
                <head>
                    <title>Resumo do Edital - ${currentFile?.name || ''}</title>
                    <script src="https://cdn.tailwindcss.com"></script>
                </head>
                <body class="p-4">${content}</body>
            </html>
        `);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
            try {
                printWindow.print();
            } catch (e) {
                console.error("Printing failed:", e);
            } finally {
                printWindow.close();
            }
        }, 500); // Timeout to allow styles to load
    };

    return (
        <div className="bg-gray-100 dark:bg-gray-900 min-h-screen font-sans text-gray-800 dark:text-gray-200">
            <Header />
            <main className="container mx-auto px-4 py-8 md:px-8">
                <div className="bg-white dark:bg-gray-800 p-6 md:p-8 rounded-2xl shadow-lg">
                    <FileUpload 
                        onFileSelect={handleFileSelect} 
                        disabled={isLoadingSummary}
                        currentFile={currentFile}
                    />

                    {error && !isLoadingSummary && (
                        <div className="mt-6 p-4 bg-red-100 dark:bg-red-900/50 border border-red-400 text-red-700 dark:text-red-200 rounded-lg">
                            <p><strong>Erro:</strong> {error}</p>
                        </div>
                    )}

                    {isLoadingSummary && <LoadingAnimation />}
                    
                    {summary && !isLoadingSummary && (
                        <div>
                            <div className="flex justify-between items-center mt-8 border-b border-gray-200 dark:border-gray-700 pb-4 mb-6">
                               <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Resumo do Edital</h2>
                               <button
                                   onClick={handlePrint}
                                   className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 dark:bg-blue-900/50 dark:text-blue-300 dark:hover:bg-blue-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                                >
                                   <PrintIcon />
                                   <span className="ml-2 hidden sm:inline">Imprimir Resumo</span>
                               </button>
                            </div>
                            <SummaryDisplay summary={summary} />
                            <ChatWindow 
                                history={chatHistory} 
                                onSendMessage={handleSendMessage} 
                                isLoading={isChatting} 
                            />
                        </div>
                    )}
                </div>
                
                {/* Hidden printable component */}
                {summary && (
                    <div className="hidden">
                        <div ref={printRef}>
                            <PrintLayout summary={summary} file={currentFile} />
                        </div>
                    </div>
                )}
            </main>
        </div>
    );
}

export default App;
