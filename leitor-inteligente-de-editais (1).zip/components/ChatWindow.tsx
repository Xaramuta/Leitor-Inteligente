import React, { useState, useRef, useEffect } from 'react';
import type { ChatMessage } from '../types';
import { SendIcon, UserIcon, BotIcon } from './icons';

interface ChatWindowProps {
    history: ChatMessage[];
    onSendMessage: (message: string) => void;
    isLoading: boolean;
}

export const ChatWindow: React.FC<ChatWindowProps> = ({ history, onSendMessage, isLoading }) => {
    const [input, setInput] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(scrollToBottom, [history, isLoading]);

    const handleSend = () => {
        if (input.trim() && !isLoading) {
            onSendMessage(input.trim());
            setInput('');
        }
    };

    const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            handleSend();
        }
    };
    
    return (
        <div className="mt-8 border-t border-gray-200 dark:border-gray-700 pt-6">
             <h3 className="flex items-center text-xl font-semibold text-gray-700 dark:text-gray-200 mb-4">
                <span role="img" aria-label="chat bubble" className="mr-3">💬</span>
                Converse com a IA
            </h3>
            <div className="bg-gray-50 dark:bg-gray-900/50 p-4 rounded-lg h-80 overflow-y-auto flex flex-col space-y-4">
                {history.map((chat, index) => (
                    <div key={index} className={`flex items-start gap-3 ${chat.sender === 'user' ? 'justify-end' : ''}`}>
                        {chat.sender === 'ai' && (
                            <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center flex-shrink-0">
                                <BotIcon />
                            </div>
                        )}
                        <div className={`p-3 rounded-xl max-w-md ${chat.sender === 'user' ? 'bg-blue-500 text-white rounded-br-none' : 'bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-bl-none'}`}>
                           <p className="text-sm" dangerouslySetInnerHTML={{ __html: chat.message.replace(/\n/g, '<br />') }} />
                        </div>
                        {chat.sender === 'user' && (
                            <div className="w-8 h-8 rounded-full bg-gray-300 dark:bg-gray-600 flex items-center justify-center flex-shrink-0">
                                <UserIcon />
                            </div>
                        )}
                    </div>
                ))}
                 {isLoading && (
                    <div className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center flex-shrink-0">
                             <BotIcon />
                        </div>
                        <div className="p-3 rounded-lg bg-white dark:bg-gray-700 flex items-center">
                            <span className="animate-pulse">Digitando...</span>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>
            <div className="mt-4 flex gap-2">
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Faça uma pergunta sobre o edital..."
                    className="flex-grow p-3 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    disabled={isLoading}
                />
                <button
                    onClick={handleSend}
                    disabled={isLoading || !input.trim()}
                    className="bg-blue-600 text-white p-3 rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed flex-shrink-0"
                >
                    <SendIcon />
                </button>
            </div>
        </div>
    );
};
