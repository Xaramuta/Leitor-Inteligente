import React, { useRef } from 'react';
import { UploadIcon } from './icons';

interface FileUploadProps {
    onFileSelect: (file: File) => void;
    disabled: boolean;
    currentFile: File | null;
}

export const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect, disabled, currentFile }) => {
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            onFileSelect(file);
        }
    };

    const handleButtonClick = () => {
        fileInputRef.current?.click();
    };
    
    const buttonText = currentFile ? "Substituir Edital" : "Carregar Edital";

    return (
        <div className="text-center p-6 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl bg-gray-50 dark:bg-gray-700/50">
            <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                className="hidden"
                accept=".pdf,.docx"
                disabled={disabled}
            />
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-blue-100 dark:bg-blue-900/50">
                <UploadIcon />
            </div>
            <h3 className="mt-4 text-lg font-semibold text-gray-900 dark:text-white">{currentFile ? 'Edital Carregado' : 'Carregue o Edital'}</h3>
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                {currentFile ? `Arquivo: ${currentFile.name}` : 'Arraste e solte ou clique para selecionar (PDF, DOCX até 25MB)'}
            </p>
            <button
                onClick={handleButtonClick}
                disabled={disabled}
                className="mt-6 inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-400 disabled:cursor-not-allowed transition-all"
            >
                {buttonText}
            </button>
        </div>
    );
};
