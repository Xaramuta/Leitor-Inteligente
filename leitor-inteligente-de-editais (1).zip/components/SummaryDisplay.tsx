import React from 'react';
import type { EditalSummary } from '../types';
import { InfoIcon, CalendarIcon, ListIcon, GavelIcon, DollarSignIcon, PackageIcon } from './icons';

interface SummaryDisplayProps {
    summary: EditalSummary;
}

const SummarySection: React.FC<{ title: string; icon: React.ReactNode; children: React.ReactNode }> = ({ title, icon, children }) => (
    <div className="mb-6 bg-gray-50 dark:bg-gray-800/50 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
        <h3 className="flex items-center text-xl font-semibold text-gray-700 dark:text-gray-200 mb-3">
            <span className="mr-3">{icon}</span>
            {title}
        </h3>
        <div className="pl-8 text-gray-600 dark:text-gray-300 space-y-2">
            {children}
        </div>
    </div>
);

const DetailItem: React.FC<{ label: string; value?: string | number | null }> = ({ label, value }) => (
    value ? <p><strong className="font-semibold text-gray-800 dark:text-gray-100">{label}:</strong> {value}</p> : null
);

export const SummaryDisplay: React.FC<SummaryDisplayProps> = ({ summary }) => {
    return (
        <div className="mt-8 space-y-6">
            <SummarySection title="Dados do Órgão Licitante" icon={<InfoIcon />}>
                <DetailItem label="Nome" value={summary.orgao_licitante.nome} />
                <DetailItem label="CNPJ" value={summary.orgao_licitante.cnpj} />
                <DetailItem label="Endereço" value={summary.orgao_licitante.endereco} />
                <DetailItem label="Contato" value={`${summary.orgao_licitante.telefone || ''} / ${summary.orgao_licitante.email || ''}`} />
                <DetailItem label="Responsável" value={summary.orgao_licitante.responsavel} />
            </SummarySection>

            <SummarySection title="Objeto da Licitação" icon={<PackageIcon />}>
                <p>{summary.objeto_licitacao}</p>
                <DetailItem label="Tipo de Disputa" value={summary.tipo_disputa} />
                <DetailItem label="Portal" value={summary.portal_processo.portal} />
                <DetailItem label="Processo Nº" value={summary.portal_processo.numero_processo} />
            </SummarySection>

            <SummarySection title="Datas Principais" icon={<CalendarIcon />}>
                <DetailItem label="Entrega de Propostas" value={summary.datas_principais.entrega_propostas} />
                <DetailItem label="Abertura" value={summary.datas_principais.abertura} />
                <DetailItem label="Disputa" value={summary.datas_principais.disputa} />
                <DetailItem label="Validade da Proposta" value={summary.datas_principais.validade_proposta} />
            </SummarySection>

            <SummarySection title="Critérios e Requisitos" icon={<GavelIcon />}>
                <DetailItem label="Critério de Julgamento" value={summary.criterio_julgamento} />
                <div>
                    <strong className="font-semibold text-gray-800 dark:text-gray-100">Requisitos de Habilitação:</strong>
                    <ul className="list-disc list-inside mt-1 space-y-1">
                        {summary.requisitos_habilitacao.map((req, index) => <li key={index}>{req}</li>)}
                    </ul>
                </div>
            </SummarySection>
            
            {summary.principais_itens?.length > 0 && (
                 <SummarySection title="Principais Itens" icon={<ListIcon />}>
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-100 dark:bg-gray-700 dark:text-gray-300">
                                <tr>
                                    <th scope="col" className="px-4 py-2">Item</th>
                                    <th scope="col" className="px-4 py-2">Descrição</th>
                                    <th scope="col" className="px-4 py-2">Qtd.</th>
                                    <th scope="col" className="px-4 py-2">Un.</th>
                                </tr>
                            </thead>
                            <tbody>
                                {summary.principais_itens.map((item, index) => (
                                    <tr key={index} className="border-b dark:border-gray-700">
                                        <td className="px-4 py-2">{item.item || '-'}</td>
                                        <td className="px-4 py-2">{item.descricao}</td>
                                        <td className="px-4 py-2">{item.quantidade || '-'}</td>
                                        <td className="px-4 py-2">{item.unidade || '-'}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                 </SummarySection>
            )}

            <SummarySection title="Condições Gerais" icon={<DollarSignIcon />}>
                <DetailItem label="Condições de Pagamento" value={summary.datas_principais.pagamento} />
                <div>
                    <strong className="font-semibold text-gray-800 dark:text-gray-100">Outros Dados Relevantes:</strong>
                    <ul className="list-disc list-inside mt-1 space-y-1">
                        {summary.outros_dados.map((dado, index) => <li key={index}>{dado}</li>)}
                    </ul>
                </div>
            </SummarySection>
        </div>
    );
};
