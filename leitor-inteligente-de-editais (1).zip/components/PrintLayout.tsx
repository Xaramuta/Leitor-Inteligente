import React from 'react';
import type { EditalSummary } from '../types';

interface PrintLayoutProps {
    summary: EditalSummary;
    file: File | null;
}

const PrintSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="mb-4 break-inside-avoid">
        <h2 className="text-lg font-bold border-b-2 border-black pb-1 mb-2">{title}</h2>
        <div className="text-sm space-y-1">
            {children}
        </div>
    </div>
);

const PrintDetailItem: React.FC<{ label: string; value?: string | number | null }> = ({ label, value }) => {
    if (!value || (typeof value === 'string' && value.trim() === '/')) {
        return null;
    }
    return <p><strong className="font-semibold">{label}:</strong> {value}</p>;
};


export const PrintLayout: React.FC<PrintLayoutProps> = ({ summary, file }) => {
    return (
        <div className="p-8 font-serif text-black bg-white">
            <header className="text-center mb-8">
                <h1 className="text-2xl font-bold">Resumo do Edital de Licitação</h1>
                {file && <p className="text-md mt-1">Arquivo: {file.name}</p>}
            </header>
            
            <main>
                <PrintSection title="Dados do Órgão Licitante">
                    <PrintDetailItem label="Nome" value={summary.orgao_licitante.nome} />
                    <PrintDetailItem label="CNPJ" value={summary.orgao_licitante.cnpj} />
                    <PrintDetailItem label="Endereço" value={summary.orgao_licitante.endereco} />
                    <PrintDetailItem label="Contato" value={`${summary.orgao_licitante.telefone || ''} / ${summary.orgao_licitante.email || ''}`} />
                    <PrintDetailItem label="Responsável" value={summary.orgao_licitante.responsavel} />
                </PrintSection>

                <PrintSection title="Objeto da Licitação">
                    <p>{summary.objeto_licitacao}</p>
                    <PrintDetailItem label="Tipo de Disputa" value={summary.tipo_disputa} />
                    <PrintDetailItem label="Portal" value={summary.portal_processo.portal} />
                    <PrintDetailItem label="Processo Nº" value={summary.portal_processo.numero_processo} />
                </PrintSection>
                
                <PrintSection title="Datas Principais">
                    <PrintDetailItem label="Entrega de Propostas" value={summary.datas_principais.entrega_propostas} />
                    <PrintDetailItem label="Abertura" value={summary.datas_principais.abertura} />
                    <PrintDetailItem label="Disputa" value={summary.datas_principais.disputa} />
                    <PrintDetailItem label="Validade da Proposta" value={summary.datas_principais.validade_proposta} />
                </PrintSection>
                
                <PrintSection title="Critérios e Requisitos">
                    <PrintDetailItem label="Critério de Julgamento" value={summary.criterio_julgamento} />
                    {summary.requisitos_habilitacao?.length > 0 && (
                        <div>
                            <strong className="font-semibold">Requisitos de Habilitação:</strong>
                            <ul className="list-disc list-inside mt-1 space-y-1">
                                {summary.requisitos_habilitacao.map((req, index) => <li key={index}>{req}</li>)}
                            </ul>
                        </div>
                    )}
                </PrintSection>

                {summary.principais_itens?.length > 0 && (
                     <PrintSection title="Principais Itens">
                        <table className="w-full text-xs text-left border-collapse border border-black">
                            <thead>
                                <tr>
                                    <th className="border border-black px-2 py-1 bg-gray-100">Item</th>
                                    <th className="border border-black px-2 py-1 bg-gray-100">Descrição</th>
                                    <th className="border border-black px-2 py-1 bg-gray-100">Qtd.</th>
                                    <th className="border border-black px-2 py-1 bg-gray-100">Un.</th>
                                </tr>
                            </thead>
                            <tbody>
                                {summary.principais_itens.map((item, index) => (
                                    <tr key={index}>
                                        <td className="border border-black px-2 py-1">{item.item || '-'}</td>
                                        <td className="border border-black px-2 py-1">{item.descricao}</td>
                                        <td className="border border-black px-2 py-1">{item.quantidade || '-'}</td>
                                        <td className="border border-black px-2 py-1">{item.unidade || '-'}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                     </PrintSection>
                )}
                
                <PrintSection title="Condições Gerais">
                    <PrintDetailItem label="Condições de Pagamento" value={summary.datas_principais.pagamento} />
                    {summary.outros_dados?.length > 0 && (
                        <div>
                            <strong className="font-semibold">Outros Dados Relevantes:</strong>
                            <ul className="list-disc list-inside mt-1 space-y-1">
                                {summary.outros_dados.map((dado, index) => <li key={index}>{dado}</li>)}
                            </ul>
                        </div>
                    )}
                </PrintSection>
            </main>
        </div>
    );
};
