import React from 'react';

export const Header: React.FC = () => {
    return (
        <header className="bg-white dark:bg-gray-800 shadow-md">
            <div className="container mx-auto px-4 py-4 md:px-8">
                <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white">
                    <span role="img" aria-label="magnifying glass" className="mr-2">🔎</span>
                    Leitor Inteligente de Editais
                </h1>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Seu assistente de IA para análise de licitações</p>
            </div>
        </header>
    );
};
