import React, { useState, useEffect } from 'react';

const loadingMessages = [
    "Analisando o edital... 🕵️‍♀️",
    "Extraindo os dados mais importantes... 🧐",
    "A IA está preparando o resumo... 🤖",
    "Verificando os critérios de habilitação... 📝",
    "Quase pronto, organizando os itens... ✨"
];

export const LoadingAnimation: React.FC = () => {
    const [message, setMessage] = useState(loadingMessages[0]);

    useEffect(() => {
        const intervalId = setInterval(() => {
            setMessage(prevMessage => {
                const currentIndex = loadingMessages.indexOf(prevMessage);
                const nextIndex = (currentIndex + 1) % loadingMessages.length;
                return loadingMessages[nextIndex];
            });
        }, 2500); // Change text every 2.5 seconds

        return () => clearInterval(intervalId); // Cleanup on unmount
    }, []);

    return (
        <div className="mt-8 text-center flex flex-col items-center justify-center space-y-4">
            <style>
                {`
                @keyframes scan {
                    0% { transform: translate(-15px, 15px) rotate(-45deg); }
                    50% { transform: translate(25px, -25px) rotate(-45deg); }
                    100% { transform: translate(-15px, 15px) rotate(-45deg); }
                }
                .scanner-animation {
                    animation: scan 3s infinite cubic-bezier(0.42, 0, 0.58, 1);
                }
                `}
            </style>
            <div className="relative w-24 h-24">
                {/* Document Icon as background */}
                <svg className="w-20 h-20 text-gray-300 dark:text-gray-600 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                
                {/* Animated Scanner */}
                <div className="absolute top-0 left-0 scanner-animation">
                     <svg className="w-12 h-12 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                </div>
            </div>
            <p className="text-lg font-semibold text-blue-600 dark:text-blue-400">
                {message}
            </p>
        </div>
    );
};