declare global {
    interface Window {
        pdfjsLib: any;
        mammoth: any;
    }
}

/**
 * Waits for a global variable to be available on the window object.
 * This is useful for ensuring CDN-loaded libraries are ready before use.
 * @param name The name of the global variable (e.g., 'pdfjsLib').
 * @param libraryDescription A user-friendly name for the library (e.g., 'PDF').
 * @param timeout The maximum time to wait in milliseconds.
 * @returns A promise that resolves with the library object.
 */
const waitForLibrary = <T>(name: string, libraryDescription: string, timeout = 7000): Promise<T> => {
    return new Promise((resolve, reject) => {
        const startTime = Date.now();
        const check = () => {
            if ((window as any)[name]) {
                resolve((window as any)[name]);
            } else if (Date.now() - startTime > timeout) {
                reject(new Error(`A biblioteca para leitura de ${libraryDescription} (${name}) não foi carregada. Verifique sua conexão à internet e tente novamente.`));
            } else {
                setTimeout(check, 100); // Check every 100ms
            }
        };
        check();
    });
};


export const extractTextFromFile = async (file: File): Promise<string> => {
    const fileType = file.type;

    if (fileType === 'application/pdf') {
        return extractTextFromPdf(file);
    } else if (fileType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
        return extractTextFromDocx(file);
    } else if (file.name.endsWith('.doc')) {
        throw new Error('Arquivos .doc antigos não são suportados. Por favor, converta para .docx ou PDF.');
    } else {
        throw new Error(`Tipo de arquivo não suportado: ${fileType}. Por favor, envie um PDF ou .docx.`);
    }
};

const extractTextFromPdf = async (file: File): Promise<string> => {
    try {
        const pdfjsLib = await waitForLibrary<any>('pdfjsLib', 'PDF');
        
        // Configure the workerSrc right before using it to avoid race conditions.
        pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js`;

        const arrayBuffer = await file.arrayBuffer();
        const typedarray = new Uint8Array(arrayBuffer);
        const pdf = await pdfjsLib.getDocument({ data: typedarray }).promise;
        
        const pagePromises = [];
        for (let i = 1; i <= pdf.numPages; i++) {
            pagePromises.push(pdf.getPage(i));
        }
        
        const pages = await Promise.all(pagePromises);
        const textContentPromises = pages.map(page => page.getTextContent());
        const textContents = await Promise.all(textContentPromises);

        let fullText = '';
        textContents.forEach(textContent => {
            fullText += textContent.items.map((item: any) => item.str).join(' ') + '\n';
        });

        return fullText;
    } catch (error: any) {
        console.error("PDF processing error:", error);
        // If it's our custom timeout error, rethrow it as is.
        if (error.message.includes('não foi carregada')) {
            throw error;
        }
        // Otherwise, throw a generic processing error.
        throw new Error('Erro ao processar o conteúdo do PDF.');
    }
};

const extractTextFromDocx = async (file: File): Promise<string> => {
    try {
        const mammoth = await waitForLibrary<any>('mammoth', 'DOCX');
        const arrayBuffer = await file.arrayBuffer();
        const result = await mammoth.extractRawText({ arrayBuffer });
        return result.value;
    } catch (error: any) {
        console.error("DOCX processing error:", error);
        if (error.message.includes('não foi carregada')) {
            throw error;
        }
        throw new Error('Erro ao processar o conteúdo do DOCX.');
    }
};